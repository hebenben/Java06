import java.util.ArrayList;
import java.util.*;

import com.sun.javafx.binding.StringFormatter;
import javafx.util.Pair;
import java.util.HashMap;

public class MusicExchangeCenter {
    private ArrayList<User> users;
    private HashMap<String, Float> royalties;
    private ArrayList<Song> downloadedSongs;

    public ArrayList<User> getUsers() {
        return users;
    }

    public  MusicExchangeCenter(){
        users=new ArrayList<User>();
        royalties = new HashMap<String, Float>();
        downloadedSongs = new ArrayList<Song>();
    }
    public HashMap<String, Float> getRoyalties() { return royalties; }
    public ArrayList<Song> getDownloadedSongs() { return downloadedSongs; }

    public ArrayList<User> onlineUsers(){
        ArrayList<User> OU=new ArrayList<>();
        for (User u:users)
            if (u.isOnline()){
            OU.add(u);
            }
        return OU;
    }

    public ArrayList<Song> allAvailableSongs(){
        ArrayList<Song> AS=new ArrayList<>();
        for (User u:users)
            if (u.isOnline())
                for (Song s:u.getSongList())
                    AS.add(s);

        return AS;
    }
    public Song getSong(String title, String ownerName) {
        for (User u:onlineUsers()) {
            if (u.getUserName().equals(ownerName)) {
                Song GS = u.songWithTitle(title);
                if (GS != null) {
                    downloadedSongs.add(GS);
                    return GS;
                }
            }
        }
        return null;
    }
    public void displayRoyalties() {
        System.out.println("Amount Artist");
        System.out.println("--------------");
        HashMap<String, Float> DR = new HashMap<>();
        for (Song s : downloadedSongs) {
            if (DR.containsKey(s.getArtist())) {
                DR.put(s.getArtist(), DR.get(s.getArtist()) + 0.25f);
            }
            else {
                DR.put(s.getArtist(), 0.25f);
            }

        }
        for (HashMap.Entry<String, Float> entry : DR.entrySet()) {
            System.out.println(String.format("$%1.2f" + "   " + entry.getKey(), entry.getValue()));
        }
    }
    public TreeSet<Song> uniqueDownloads() {
        TreeSet<Song> UD = new TreeSet<Song>(new Comparator<Song>() {
            public int compare(Song a, Song b) {
                return a.getTitle().compareTo(b.getTitle());
            }
        });
        UD.addAll(downloadedSongs);
        return UD;
    }

    public ArrayList<Pair<Integer, Song>> songsByPopularity() {
        ArrayList<Pair<Integer, Song>> SBP = new ArrayList<Pair<Integer, Song>>();
        for (Song s : uniqueDownloads()) {
            SBP.add(new Pair<Integer, Song>((int)(royalties.get(s.getTitle())/0.25), s));
        }
        Collections.sort(SBP, new Comparator<Pair<Integer, Song>>() {
            public int compare(Pair<Integer, Song> p1, Pair<Integer, Song> p2) {
                return -(p1.getKey() - p2.getKey());
            }
        });
        return SBP;

    }

/*
    public ArrayList<Song> getSong(String title, String ownerName){
        ArrayList<Song> GS=new ArrayList<>();
        for (Song s:allAvailableSongs())
            if (s!=null){
                if (s.getTitle().equals(title)&&s.owner.equals(ownerName)){
                    GS.add(s);
                    return GS;
                }
                return null;
        }

        return null;
    }*/
    @Override
    public String toString() {
        return ("Music Exchange Center ("+onlineUsers().size()+" users on line, "+allAvailableSongs().size()+" songs available)");
    }
    public ArrayList<User> userWithName(String s){
        ArrayList<User> uWN=new ArrayList<>();
        for (User u:users)
            if(u.getUserName().equals(s)){
                uWN.add(u);
        }
        return uWN;
    }
    public void registerUser(User x){
        if(!users.contains(x)){
            users.add(x);
        }
    }
    public ArrayList<Song> availableSongsByArtist(String artist){
        ArrayList<Song> ASBA=new ArrayList<>();
        for(Song s:allAvailableSongs())
            if (s.getArtist().equals(artist))
                ASBA.add(s);
        return ASBA;
    }
}
